#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "9be7270fcc"     # abbreviated commit hash
commit = "9be7270fcc6157746c05770d2cbf5c8e534b0281"  # commit hash
date = "2021-07-08 11:33:08 +0200"   # commit date
author = "Rok Mandeljc <rok.mandeljc@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Revert "hooks: setuptools: Exclude outdated compat modules." (#5979)

This reverts commit 00dcae2a77ead2eed805bdc25eaff4927ecf2b46.

While the setuptools.py27compat and setuptools.py33compat are
aimed at obsolete python versions, their exclusion and subsequent
absence causes ModuleNotFoundError when setuptools tries to import
them from its other modules (see #5973).

This affects older versions of setuptools (e.g., 40.x that comes
with python 3.6). In newer versions, these modules are not present
anymore (and them being in excludedimports probably generates
"Import to be excluded not found" warnings during build process)."""
