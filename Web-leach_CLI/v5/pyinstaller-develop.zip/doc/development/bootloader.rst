.. _bootloader:

Bootloader Internals
--------------------


