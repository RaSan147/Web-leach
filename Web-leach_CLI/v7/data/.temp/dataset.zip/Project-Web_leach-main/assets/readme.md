Simple assets goes here
