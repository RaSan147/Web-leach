Data entry #3 in ``subpkg1/data``.
