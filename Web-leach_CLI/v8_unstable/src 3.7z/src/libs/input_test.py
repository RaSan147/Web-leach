import ERR

try:
    x= input()
    print(x)
except Exception as e:
    print("Cancelled")