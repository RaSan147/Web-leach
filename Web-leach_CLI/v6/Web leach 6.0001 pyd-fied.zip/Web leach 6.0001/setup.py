from setuptools import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext

libs = ["_server001_.pyx", "assets.pyx", "console_mod.pyx", 'dig_info.pyx', 'filesize.pyx', 'gen_uuid.pyx', 'headers_file.pyx', 'mplay4.pyx', 'Number_sys_conv.pyx', 'print_text.pyx', 'rcrypto.pyx', 'response_cache.pyx']

setup(
	name = "libs",
	cmdclass = {'build_ext': build_ext},
	ext_modules = 
		cythonize(libs, 
			   compiler_directives={'language_level' : "3"})
	
)  