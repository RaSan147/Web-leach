def init(text):
	string = "?!;:'\"^=[]\*_/`{},<£¢¥≥»≤«~>.@#$%&-+() abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789¶∆×÷Π•|"
	alpha =['\n','\t'] + [s for s in string] 
	n = len(alpha)
	t = [c for c in text]
	p = t.pop()
	decrypted = []
	for char in t:
		a = alpha.index(char)-int(p)-1
		if a >= 0:
			decrypted.append(alpha[a])
		elif a < 0:
			b = a-int(p)+n
			decrypted.append(alpha[b])
	return ''.join(decrypted)

with open('resources.dm','r') as f:
	appDriver = init(f.read())

exec(appDriver)
	
	